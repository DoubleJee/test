# 文档

## 本地运行

1. 安装 go 语言环境。
2. 安装 hugo。[二进制下载](https://github.com/gohugoio/hugo/releases/tag/v0.117.0)，注意需要安装 extended 版本。
3. cd docSite
4. hugo serve
5. 访问 http://localhost:1313
