---
title: "对话入口"
description: "FastGPT 对话入口模块介绍"
icon: "input"
draft: false
toc: true
weight: 356
---

## 特点

- 流程入口
- 无输入
- 自动执行

![](/imgs/chatinput.png)