---
weight: 900
title: '本地模型使用'
description: 'FastGPT 对接本地模型'
icon: 'model_training'
draft: false
images: []
---
<!-- 900~950 -->