---
title: '加入社区'
description: ' 加入 FastGPT 开发者社区和我们一起成长'
icon: 'forum'
draft: false
toc: true
weight: 1300
---

FastGPT 是一个由用户和贡献者参与推动的开源项目，如果您对产品使用存在疑问和建议，可尝试以下方式寻求支持。我们的团队与社区会竭尽所能为您提供帮助。

+ 📱 扫码加入社区微信交流群👇

   <img width="400px" src="https://oss.laf.run/otnvvf-imgs/fastgpt-feishu1.png" class="medium-zoom-image" />

+ 🐞 请将任何 FastGPT 的 Bug、问题和需求提交到 [GitHub Issue](https://github.com/labring/fastgpt/issues/new/choose)。