---
title: '线上版定价'
description: 'FastGPT 线上版定价'
icon: 'currency_yen'
draft: false
toc: true
weight: 1002
type: redirect
target: https://cloud.tryfastgpt.ai/price
---

线上版价格请查看：[https://cloud.tryfastgpt.ai/price](https://cloud.tryfastgpt.ai/price)