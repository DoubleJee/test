---
title: 'FAQ'
description: '常见问题的解答'
icon: 'quiz'
draft: false
toc: true
weight: 900
---
<!-- 9800 ~ 1000 -->

FastGPT 是一个由用户和贡献者参与推动的开源项目，如果您对产品使用存在疑问和建议，可尝试[加入社区](community)寻求支持。我们的团队与社区会竭尽所能为您提供帮助。