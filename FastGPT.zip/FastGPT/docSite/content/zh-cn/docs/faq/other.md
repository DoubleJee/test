---
title: '其他问题'
icon: 'quiz'
draft: false
toc: true
weight: 925
---

## oneapi 官网是哪个

只有开源的 README，没官网，GitHub: https://github.com/songquanpeng/one-api