export enum LogLevelEnum {
  debug = 0,
  info = 1,
  warn = 2,
  error = 3
}

export enum LogSignEnum {
  slowOperation = 'slowOperation'
}
