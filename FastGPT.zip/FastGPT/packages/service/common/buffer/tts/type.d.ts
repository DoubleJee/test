export type TTSBufferSchemaType = {
  bufferId: string;
  text: string;
  buffer: Buffer;
};
