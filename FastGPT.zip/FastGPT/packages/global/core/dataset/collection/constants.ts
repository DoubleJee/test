/* sourceId = prefix-id; id=fileId;link url;externalFileId */
export enum CollectionSourcePrefixEnum {
  local = 'local',
  link = 'link',
  external = 'external'
}
