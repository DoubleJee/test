import OpenAI from 'openai';
export default OpenAI;
