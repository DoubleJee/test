export const getHandleConfig = (top: boolean, right: boolean, bottom: boolean, left: boolean) => ({
  top,
  right,
  bottom,
  left
});
