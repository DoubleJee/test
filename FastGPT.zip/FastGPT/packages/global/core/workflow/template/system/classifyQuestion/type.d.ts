export type ClassifyQuestionAgentItemType = {
  value: string;
  key: string;
};
