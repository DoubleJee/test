export type AiChatQuoteRoleType = 'user' | 'system';
