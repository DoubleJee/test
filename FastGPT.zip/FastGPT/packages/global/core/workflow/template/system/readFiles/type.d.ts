export type ReadFileNodeResponse = {
  url: string;
  name: string;
}[];
