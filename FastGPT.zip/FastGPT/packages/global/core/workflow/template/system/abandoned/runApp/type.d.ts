export type SelectAppItemType = {
  id: string;
  // name: string;
  // logo?: string;
};
