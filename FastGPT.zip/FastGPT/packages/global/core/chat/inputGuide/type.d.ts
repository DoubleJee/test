export type ChatInputGuideSchemaType = {
  _id: string;
  appId: string;
  text: string;
};
