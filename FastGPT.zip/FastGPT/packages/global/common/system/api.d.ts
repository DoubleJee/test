export type AuthGoogleTokenProps = { googleToken: string; remoteip?: string | null };
