export type AuthFrequencyLimitProps = {
  eventId: string;
  maxAmount: number;
  expiredTime: Date;
};
