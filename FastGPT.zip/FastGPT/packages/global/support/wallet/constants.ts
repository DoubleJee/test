// model price: xxx/1k tokens
// ￥1 = 100000.
export const PRICE_SCALE = 100000;
