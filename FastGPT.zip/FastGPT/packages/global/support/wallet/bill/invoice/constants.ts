export enum InvoiceStatusEnum {
  submitted = 1,
  completed = 2
}
