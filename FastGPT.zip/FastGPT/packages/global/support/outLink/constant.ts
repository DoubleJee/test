export enum PublishChannelEnum {
  share = 'share',
  iframe = 'iframe',
  apikey = 'apikey',
  feishu = 'feishu',
  wecom = 'wecom',
  officialAccount = 'official_account'
}
