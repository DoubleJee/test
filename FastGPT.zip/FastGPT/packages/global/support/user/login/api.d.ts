export type GetWXLoginQRResponse = {
  code: string;
  codeUrl: string;
};
