export const DefaultGroupName = 'DEFAULT_GROUP';
